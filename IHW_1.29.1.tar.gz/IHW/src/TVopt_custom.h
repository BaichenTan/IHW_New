#ifndef TVOPT_CUSTOM_H
#define TVOPT_CUSTOM_H

extern "C" {
  int classicTautString_TV1(double* input, int length, double lambda, double* output);
}

#endif /* TVOPT_CUSTOM_H */
