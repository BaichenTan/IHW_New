# easiest unit test we can have it check if Benjamini Hochberg and ddhw with regularization
# parameter = 0 returns the same result..